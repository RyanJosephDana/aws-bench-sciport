import { describe, expect, test } from "vitest";
import { buildChangeSet, renderChangeSet, summarize, gitlabMrReport } from "./change-set";
import type { ResourceMetadata } from "../lexicon";

const meta = (over: Partial<ResourceMetadata> = {}): ResourceMetadata => ({
  type: "Fake::Resource",
  status: "OK",
  ...over,
});

describe("buildChangeSet (#118)", () => {
  test("declared but not live → create", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(["bucket"]),
      observedNow: {},
      observedThen: undefined,
    });
    const e = cs.entries.find((x) => x.name === "bucket")!;
    expect(e.action).toBe("create");
    expect(e.evidence).toEqual({ declared: true, inSnapshot: false, live: false });
    expect(e.ownership).toBe("unknown");
  });

  test("declared and live with drift since snapshot → update with deltas", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(["queue"]),
      observedNow: { queue: meta({ status: "ACTIVE" }) },
      observedThen: { queue: meta({ status: "CREATING" }) },
    });
    const e = cs.entries.find((x) => x.name === "queue")!;
    expect(e.action).toBe("update");
    expect(e.deltas).toEqual([{ path: "status", oldValue: "CREATING", newValue: "ACTIVE" }]);
  });

  test("declared and live, unchanged → noop", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(["queue"]),
      observedNow: { queue: meta({ status: "ACTIVE" }) },
      observedThen: { queue: meta({ status: "ACTIVE" }) },
    });
    expect(cs.entries.find((x) => x.name === "queue")!.action).toBe("noop");
  });

  test("live but undeclared, no ownership data → adopt, never delete", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: { orphan: meta() },
      observedThen: undefined,
    });
    const e = cs.entries.find((x) => x.name === "orphan")!;
    expect(e.action).toBe("adopt");
    expect(e.ownership).toBe("unknown");
  });

  test("owned orphan → delete (#121)", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: { orphan: meta({ ownership: "owned" }) },
      observedThen: undefined,
    });
    const e = cs.entries.find((x) => x.name === "orphan")!;
    expect(e.action).toBe("delete");
    expect(e.ownership).toBe("owned");
  });

  test("foreign orphan → adopt, never delete (#121)", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: { orphan: meta({ ownership: "foreign" }) },
      observedThen: undefined,
    });
    const e = cs.entries.find((x) => x.name === "orphan")!;
    expect(e.action).toBe("adopt");
    expect(e.ownership).toBe("foreign");
  });

  test("snapshot is never load-bearing: ownership/delete ignores observedThen", () => {
    // The same live orphan, once with a rich snapshot and once with none.
    // The delete decision must depend only on the LIVE ownership marker, so the
    // result must be identical regardless of what the snapshot says.
    const withSnapshot = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: { orphan: meta({ ownership: "owned" }) },
      observedThen: { orphan: meta({ ownership: "foreign", status: "STALE" }) },
    });
    const withoutSnapshot = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: { orphan: meta({ ownership: "owned" }) },
      observedThen: undefined,
    });
    const a = withSnapshot.entries.find((x) => x.name === "orphan")!;
    const b = withoutSnapshot.entries.find((x) => x.name === "orphan")!;
    expect(a.action).toBe("delete");
    expect(a.ownership).toBe("owned");
    expect(a.action).toBe(b.action);
    expect(a.ownership).toBe(b.ownership);
  });

  test("never proposes a delete without ownership data", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(["a"]),
      observedNow: { b: meta(), c: meta() }, // two orphans
      observedThen: { b: meta(), c: meta() },
    });
    expect(cs.entries.some((e) => e.action === "delete")).toBe(false);
    expect(cs.entries.filter((e) => e.action === "adopt").map((e) => e.name)).toEqual(["b", "c"]);
  });

  test("only in snapshot (gone now, undeclared) → noop", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: {},
      observedThen: { ghost: meta() },
    });
    expect(cs.entries.find((x) => x.name === "ghost")!.action).toBe("noop");
  });

  test("entries are sorted by name", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(["z", "a", "m"]),
      observedNow: {},
      observedThen: undefined,
    });
    expect(cs.entries.map((e) => e.name)).toEqual(["a", "m", "z"]);
  });
});

describe("summarize / renderChangeSet", () => {
  const cs = buildChangeSet("prod", {
    declared: new Set(["create-me", "keep-me"]),
    observedNow: { "keep-me": meta(), orphan: meta() },
    observedThen: { "keep-me": meta() },
  });

  test("summarize counts each action", () => {
    const counts = summarize(cs);
    expect(counts.create).toBe(1);
    expect(counts.noop).toBe(1);
    expect(counts.adopt).toBe(1);
    expect(counts.delete).toBe(0);
  });

  test("render shows the env and grouped sections", () => {
    const out = renderChangeSet(cs);
    expect(out).toContain("Plan for prod");
    expect(out).toContain("CREATE:");
    expect(out).toContain("create-me");
    expect(out).toContain("ADOPT:");
    expect(out).toContain("orphan");
  });
});

describe("gitlabMrReport (#329)", () => {
  test("counts only create/update/delete; adopt and noop are excluded", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(["new-bucket", "drifted-queue", "stable-topic"]),
      observedNow: {
        "drifted-queue": meta({ status: "ACTIVE" }), // declared+live+drift → update
        "stable-topic": meta({ status: "OK" }), // declared+live, no drift → noop
        "owned-orphan": meta({ ownership: "owned" }), // owned orphan → delete
        "foreign-orphan": meta({ ownership: "foreign" }), // foreign orphan → adopt
        // new-bucket: declared, not live → create
      },
      observedThen: {
        "drifted-queue": meta({ status: "CREATING" }),
        "stable-topic": meta({ status: "OK" }),
      },
    });
    expect(gitlabMrReport(cs)).toEqual({ create: 1, update: 1, delete: 1 });
  });

  test("empty plan reports all zeros", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: {},
      observedThen: undefined,
    });
    expect(gitlabMrReport(cs)).toEqual({ create: 0, update: 0, delete: 0 });
  });

  test("adopt-only plan reports zeros — the widget never shows undeclared resources", () => {
    const cs = buildChangeSet("prod", {
      declared: new Set(),
      observedNow: { orphan: meta() }, // unknown ownership → adopt
      observedThen: undefined,
    });
    expect(gitlabMrReport(cs)).toEqual({ create: 0, update: 0, delete: 0 });
  });
});
