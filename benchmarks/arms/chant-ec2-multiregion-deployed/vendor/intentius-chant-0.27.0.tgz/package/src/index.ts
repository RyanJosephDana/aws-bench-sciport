/**
 * chant Core
 *
 * Lexicon-agnostic declarative specification system
 */

export * from "./declarable";
export * from "./composite";
export * from "./provenance";
export * from "./build-params";
export * from "./intrinsic";
export * from "./types";
export * from "./errors";
export * from "./attrref";
export * from "./utils";
export * from "./builder";
export * from "./serializer";
export * from "./lexicon-output";
export * from "./discovery/files";
export * from "./discovery/import";
export * from "./discovery/collect";
export * from "./discovery/cycles";
export * from "./sort";
export * from "./discovery/resolve";
export * from "./discovery/graph";
export * from "./discovery/index";
export * from "./discovery/cache";
export * from "./build";
export * from "./env";
export * from "./graph-ir";
export * from "./graph-detail";
export * from "./graph-mermaid";
export * from "./graph-dot";
export * from "./graph-layout";
export * from "./graph-lens";
export * from "./detectLexicon";
export * from "./fold/fold";
export * from "./lint/parser";
export * from "./lint/rule";
export * from "./lint/rules";
export * from "./lint/declarative";
export * from "./lint/selectors";
export * from "./lint/named-checks";
export * from "./lint/post-synth";
export * from "./lint/policy";
export * from "./lint/rule-loader";
export * from "./lint/discover";
export * from "./import/parser";
export * from "./import/generator";
export * from "./lexicon";
export * from "./lexicon-integrity";
export * from "./lexicon-manifest";
export * from "./lexicon-schema";
export * from "./config";
export * from "./validation";
export * from "./project-validation";
export * from "./codegen/naming";
export * from "./codegen/fetch";
export * from "./codegen/generate";
export * from "./codegen/package";
export * from "./codegen/typecheck";
export * from "./codegen/coverage";
export * from "./codegen/validate";
export * from "./codegen/docs";
export * from "./codegen/surface-snapshot";
export {
  regenLexicon,
  writeSurfaceSnapshot,
  SNAPSHOT_FILENAME,
  type RegenOptions,
  type RegenResult,
  type RegenFailure,
} from "./codegen/lexicon-regen";
export {
  checkRollingUpgrade,
  classifyDelta,
  diffRollingSurface,
  computeAzureApiVersionDelta,
  diffAzureApiVersions,
  extractAzureProvider,
  type RollingLexicon,
  type RollingUpgradeResult,
  type CheckRollingUpgradeOptions,
  type AzureApiVersionChange,
} from "./codegen/rolling-upgrade";
export {
  checkPinnedUpgrade,
  applyPinnedVersionBump,
  isNewer,
  parseVersion,
  isPreRelease,
  type LexiconId,
  type UpgradeCheckResult,
  type CheckPinnedUpgradeOptions,
  type UpstreamResolver,
} from "./codegen/pinned-upgrade";
export * from "./runtime";
export * from "./runtime-adapter";
export * from "./resource-attributes";
export * from "./stack-output";
export * from "./child-project";
export * from "./lsp/types";
export * from "./lsp/lexicon-providers";
export * from "./mcp/types";
export * from "./lifecycle/index";
// Op builders — use explicit exports to avoid collision with the core `build` function
export { Op, phase, activity, gate, kubectlApply, helmInstall, waitForStack,
         gitlabPipeline, lifecycleSnapshot, shell, teardown, OpResource } from "./op/index";
export type { OpConfig, PhaseDefinition, StepDefinition, ActivityStep, GateStep } from "./op/index";
